package libraryattendanceencoder.ant;

/**
 *
 * @author dux
 */
public class LibraryAttendanceEncoderAnt {

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}